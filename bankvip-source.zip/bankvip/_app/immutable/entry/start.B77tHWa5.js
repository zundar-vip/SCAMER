import{l as o,a as r}from"../chunks/CdtCp1hV.js";export{o as load_css,r as start};
